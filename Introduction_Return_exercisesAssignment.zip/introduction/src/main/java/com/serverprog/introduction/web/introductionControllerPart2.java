package com.serverprog.introduction.web;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
@Controller
@ResponseBody
//controller for the second exercise
public class introductionControllerPart2 {
	@RequestMapping("/hello")
	public String localisation(@RequestParam(name="location")String location,@RequestParam(name="name")String name) {
		return "Welcome to the " + location + " " + name;
	}
}
